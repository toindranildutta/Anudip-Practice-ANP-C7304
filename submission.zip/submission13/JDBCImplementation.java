package submission13;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class JDBCImplementation {
	static final String JDBC_URL = "jdbc:mysql://localhost:3306/anpc7304";
    static final String USERNAME = "root";
    static final String PASSWORD = "Test@1234";

    public static void main(String[] args) {
        try {
            // Establish connection
            Connection connection = DriverManager.getConnection(JDBC_URL, USERNAME, PASSWORD);

            // Create
            createEmployee(connection, "John Doe", 30, "Software Engineer");

            // Read
            readEmployees(connection);

            // Update
            updateEmployee(connection, 1, "Jane Smith", 35, "Senior Software Engineer");

            // Read again
            readEmployees(connection);

            // Delete
            deleteEmployee(connection, 1);

            // Read again
            readEmployees(connection);

            // Close connection
            connection.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // Create operation
    static void createEmployee(Connection connection, String name, int age, String designation) throws SQLException {
        String query = "INSERT INTO Employee (name, age, designation) VALUES (?, ?, ?)";
        PreparedStatement preparedStatement = connection.prepareStatement(query);
        preparedStatement.setString(1, name);
        preparedStatement.setInt(2, age);
        preparedStatement.setString(3, designation);
        int rowsAffected = preparedStatement.executeUpdate();
        System.out.println(rowsAffected + " row(s) inserted.");
        preparedStatement.close();
    }

    // Read operation
    static void readEmployees(Connection connection) throws SQLException {
        String query = "SELECT * FROM Employee";
        Statement statement = connection.createStatement();
        ResultSet resultSet = statement.executeQuery(query);
        while (resultSet.next()) {
            System.out.println("ID: " + resultSet.getInt("id") +
                    ", Name: " + resultSet.getString("name") +
                    ", Age: " + resultSet.getInt("age") +
                    ", Designation: " + resultSet.getString("designation"));
        }
        resultSet.close();
        statement.close();
    }

    // Update operation
    static void updateEmployee(Connection connection, int id, String name, int age, String designation) throws SQLException {
        String query = "UPDATE Employee SET name=?, age=?, designation=? WHERE id=?";
        PreparedStatement preparedStatement = connection.prepareStatement(query);
        preparedStatement.setString(1, name);
        preparedStatement.setInt(2, age);
        preparedStatement.setString(3, designation);
        preparedStatement.setInt(4, id);
        int rowsAffected = preparedStatement.executeUpdate();
        System.out.println(rowsAffected + " row(s) updated.");
        preparedStatement.close();
    }

    // Delete operation
    static void deleteEmployee(Connection connection, int id) throws SQLException {
        String query = "DELETE FROM Employee WHERE id=?";
        PreparedStatement preparedStatement = connection.prepareStatement(query);
        preparedStatement.setInt(1, id);
        int rowsAffected = preparedStatement.executeUpdate();
        System.out.println(rowsAffected + " row(s) deleted.");
        preparedStatement.close();
    }
	
}

package submission03;

public class Gulmarg extends HillStations{

	void location() {
		System.out.println("This is Gulmarg");
	}
	void famousFor() {
		System.out.println("I am famous for Gulmarg");
	}
	
	public static void main(String[] args) {
		
		HillStations obj = new Gulmarg();
		obj.location();
		obj.famousFor();
	}

}

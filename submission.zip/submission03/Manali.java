package submission03;

public class Manali extends HillStations {
	void location() {
		System.out.println("This is Manali");
	}
	void famousFor() {
		System.out.println("I am famous for the hills beauty");
	}
	
	public static void main(String[] args) {
		
		HillStations obj = new Manali();
		obj.location();
		obj.famousFor();
	}

}

package submission03;

public class HillStations {
	// superclass location method
	void location(){
		System.out.println("This is superclass Hillstation");
	}
	// superclass famousfor method
	void famousFor() {
		System.out.println("This is superclass Famous Location");
	}
public static void main(String[] args) {
		
		HillStations obj = new Mussoorie();
		obj.location();
		obj.famousFor();
	}

}

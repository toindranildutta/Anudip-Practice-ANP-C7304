package submission03;

public class Cat extends Dog{

	void makeSound() {
		System.out.println("The cat meows");
	}

	public static void main(String[] args) {
		Dog myCat = new Cat();
		myCat.makeSound();

	}

}

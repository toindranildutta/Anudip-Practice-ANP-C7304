package submission03;

public class Animal {
	void makeSound() {
		System.out.println("The animal makes a sound.");
	}
}

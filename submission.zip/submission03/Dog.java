package submission03;

public class Dog extends Animal{
	void makeSound() {
		System.out.println("The dog barks");
	}

	public static void main(String[] args) {
		Animal myDog = new Dog();
		myDog.makeSound();

	}

}

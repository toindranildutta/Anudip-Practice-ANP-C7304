package submission03;

public class Mussoorie extends HillStations{

	void location() {
		System.out.println("This is Mussoorie");
	}
	void famousFor() {
		System.out.println("I am famous for Mussoorie");
	}
	
	public static void main(String[] args) {
		
		HillStations obj = new Mussoorie();
		obj.location();
		obj.famousFor();
	}

}

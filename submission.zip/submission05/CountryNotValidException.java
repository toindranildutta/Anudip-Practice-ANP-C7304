package submission05;

public class CountryNotValidException extends Exception{
		public CountryNotValidException(String str) {
			super(str);
		}
	
}

package submission05;

public class EmployeeNameInvalidException extends Exception{
	public EmployeeNameInvalidException(String str) {
		super(str);
	}
}

package submission05;

public class TaxNotEligibleException extends Exception{
	public TaxNotEligibleException(String str) {
		super(str);
	}
}

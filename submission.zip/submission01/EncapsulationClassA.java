package submission01;

public class EncapsulationClassA {
	/*
	1.Write a Java Program to implement Encapsulation using setters and getters

	classname: EncapsulationClassA

	           EncapsulationClassB

	declare three private variables in EncapsulationClassA:

	          userName

	          userAge

	          userPhnNo
	 */
	
	private String userName; //variables
	private int userAge;
	private long userPhnNo;
	
	//for username
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	
	//for userage
	public int getUserAge() {
		return userAge;
	}
	public void setUserAge(int userAge) {
		this.userAge = userAge;
	}
	
	//for userphoneno
	public long getUserPhnNo() {
		return userPhnNo;
	}
	public void setUserPhnNo(long userPhnNo) {
		this.userPhnNo = userPhnNo;
	}

}

package submission01;

public class EncapsulationClassB {

	public static void main(String[] args) {
		
		EncapsulationClassA obj = new EncapsulationClassA();
		
		//for name
		obj.setUserName("Indranil Dutta");
		System.out.println(obj.getUserName());
		
		//for age
		obj.setUserAge(99);
		System.out.println(obj.getUserAge());
		
		//for phone no
		obj.setUserPhnNo(5545554545l);
		System.out.println(obj.getUserPhnNo());

	}

}

package submission02;

public class ClassB extends ClassA {
	void m2() {
		System.out.println("ClassB has everything");
	}

	public static void main(String[] args) {
		ClassB obj = new ClassB();
		obj.m1();
		obj.m2();

	}

}

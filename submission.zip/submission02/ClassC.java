package submission02;

public class ClassC extends ClassB{
	void m3() {
		System.out.println("ClassC is nothing");
	}
	
	public static void main(String[] args) {
		ClassC obj = new ClassC();
		obj.m1();
		obj.m2();
		obj.m3();

	}

}

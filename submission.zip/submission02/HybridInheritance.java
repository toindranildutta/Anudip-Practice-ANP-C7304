package submission02;

public class HybridInheritance extends ClassA{
	
	//1.. Write a Java Program to implement HybridInheritance


	public static void main(String[] args) {
		
		HybridInheritance obj = new HybridInheritance();
		obj.m1();
	}

}

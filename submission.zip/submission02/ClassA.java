package submission02;


public class ClassA {
	void m1() {
		System.out.println("ClassA is something");
	}
	public static void main(String[] args) {
		ClassA obj = new ClassA();
		obj.m1();

	}

}
